# Portfolio MDM4U final

Les pages du portfolio contiennent maintenant les réponses calculées pour les exercices 2.2 à 2.5. Les documents Word dans `answer-documents` contiennent la version complète et mise en page des réponses.

## Mettre le site sur GitHub

1. Ouvre `https://github.com/charliekerrk/MDM4U`.
2. Clique sur **Add file**, puis **Upload files**.
3. Téléverse tous les fichiers `.html` et `nav.html` directement à la racine du dépôt.
4. Téléverse aussi le dossier `answer-documents` si tu veux garder les réponses dans le dépôt.
5. Clique sur **Commit changes**.
6. Attends quelques minutes et recharge `https://charliekerrk.github.io/MDM4U/`.

Les liens vers les énoncés originaux et le classeur Google Sheets sont déjà intégrés. Les cinq fichiers Word peuvent être importés manuellement dans Google Drive avec **Nouveau > Importer un fichier**, puis **Ouvrir avec Google Docs**.
